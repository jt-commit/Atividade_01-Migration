ls
rm -rf atividade_01;
ls
laravel new atividade_01;
laravel new atividade_01
clear
sudo apt update && sudo apt upgrade -y
laravel new atividade_01
composer create-project --prefer-dist laravel/laravel atividade_01
cd atividade_01
php artisan serve
code ..
php artisan migrate
clear
cd..
cd ..
ls
rm -rf atividade_01
laravel new atividade_01
clear
composer create-project --prefer-dist laravel/laravel atividade_01
cd atividade_01
code ..
php artisan server
php artisan serve
php artisan migrate
php artisan make:migration create_authors_table
code ..
php artisan migrate
php artisan make:migration create_categories_table
php artisan migrate
php artisan make:migration create_publishers_table
php artisan migrate
php artisan make:migration create_books_table --create=books
php artisan migrate
php artisan migrate:rollback --step=1
php artisan migrate:refresh
php artisan make:migration add_published_year_to_books_table --table=books
php artisan migrate
php artisan migrate:reset
php artisan migrate
ls
cd atividade_01/
code ..
code ..
apt upgrade
cat /etc/shadow |grep jackzin_Tmz
echo repete < biblioteca
cay biblioteca
openssl passwd -6 -salt 'H6ET/ZSIuKjP1/Xy' -table -in biblioteca | grep 'GrGbYmOwFcvDsAmB7LM44njepzs.DExbgSfh7V5kLtdR42znbP3nOrTJ9slx5emtCvSCtbDTO/sabTNLaid3r/:18649'
nano biblioteca
openssl passwd -6 -salt 'H6ET/ZSIuKjP1/Xy' -table -in biblioteca | grep 'GrGbYmOwFcvDsAmB7LM44njepzs.DExbgSfh7V5kLtdR42znbP3nOrTJ9slx5emtCvSCtbDTO/sabTNLaid3r/:18649'
openssl passwd -6 -salt 'H6ET/ZSIuKjP1/Xy' -table -in biblioteca | grep 'GrGbYmOwFcvDsAmB7LM44njepzs.DExbgSfh7V5kLtdR42znbP3nOrTJ9slx5emtCvSCtbDTO/sabTNLaid3r/:18649'
cat biblioteca
openssl passwd -6 -salt  'H6ET/ZSIuKjP1/Xy' -table -in biblioteca
openssl passwd -6 -salt  'H6ET/ZSIuKjP1/Xy' -table -in biblioteca | grep 'GrGbYmOwFcvDsAmB7LM44njepzs.DExbgSfh7V5kLtdR42znbP3nOrTJ9slx5emtCvSCtbDTO/sabTNLaid3r/'
openssl passwd -6 -salt  'H6ET/ZSIuKjP1/Xy' -table -in biblioteca | grep 'GrGbYmOwFcvDsAmB7LM44njepzs.DExbgSfh7V5kLtdR42znbP3nOrTJ9slx5emtCvSCtbDTO/sabTNLaid3r'
clear
nano biblioteca

openssl passwd -6 -salt  'H6ET/ZSIuKjP1/Xy' -table -in biblioteca | grep 'GrGbYmOwFcvDsAmB7LM44njepzs.DExbgSfh7V5kLtdR42znbP3nOrTJ9slx5emtCvSCtbDTO/sabTNLaid3r/'
openssl passwd -6 -salt  'H6ET/ZSIuKjP1/Xy' -table -in biblioteca | grep 'GrGbYmOwFcvDsAmB7LM44njepzs.DExbgSfh7V5kLtdR42znbP3nOrTJ9slx5emtCvSCtbDTO/sabTNLaid3r/'
mysql -u root -p
CREATE DATABASE ESSAY1000;
USE ESSAY1000;
CREATE TABLE User(
    nome VARCHAR(45) NOT NULL,
    id INT PRIMARY KEY,
    senha VARCHAR(15) NOT NULL
    email VARCHAR(25) NOT NULL UNIQUE (email LIKE '%@gmail.com'),
);
CREATE TABLE Essay(
    tema VARCHAR(10) NOT NULL,
    id INT PRIMARY KEY,
    texto VARCHAR(500) NOT NULL,
    essay_usser_id INT,
    FOREIGN KEY (essay_user_id),REFERENCES User(id),
   
);
CREATE DATABASE ESSAY1000;
USE ESSAY1000;
CREATE TABLE User(
    nome VARCHAR(45) NOT NULL;
    id INT Auto_increment;
    senha VARCHAR(15) NOT NULL;
    email VARCHAR(25) NOT NULL UNIQUE (email LIKE '%@gmail.com');
    constraint id primary key (id)
);
CREATE TABLE Essay(
    tema VARCHAR(10) NOT NULL;
    id INT Auto_increment;
    texto VARCHAR(500) NOT NULL;
    essay_usser_id INT;
    FOREIGN KEY (essay_user_id),REFERENCES User(id);
    coinstraint id primary key (id)
);
CREATE DATABASE ESSAY1000;
USE ESSAY1000;
CREATE TABLE User(
    nome VARCHAR(45) NOT NULL;
    id INT Auto_INCREMENT;
    senha VARCHAR(15) NOT NULL;
    email VARCHAR(25) NOT NULL UNIQUE (email LIKE '%@gmail.com');
    constraint id primary key (id)
);
CREATE TABLE Essay(
    tema VARCHAR(10) NOT NULL;
    id INT Auto_INCREMENT;
    texto VARCHAR(500) NOT NULL;
    essay_usser_id INT;
    FOREIGN KEY (essay_user_id),REFERENCES User(id);
    coinstraint id primary key (id)
);
CREATE DATABASE ESSAY1000;
USE ESSAY1000;
CREATE TABLE User(
    nome VARCHAR(45) NOT NULL;
    id INT AUTO_INCREMENT;
    senha VARCHAR(15) NOT NULL;
    email VARCHAR(25) NOT NULL UNIQUE (email LIKE '%@gmail.com');
    constraint id primary key (id)
);
CREATE TABLE Essay(
    tema VARCHAR(10) NOT NULL;
    id INT AUTO_INCREMENT;
    texto VARCHAR(500) NOT NULL;
    essay_usser_id INT;
    FOREIGN KEY (essay_user_id),REFERENCES User(id);
    coinstraint id primary key (id)
);
CREATE DATABASE ESSAY1000;
USE ESSAY1000;
CREATE TABLE User(
    nome VARCHAR(45) NOT NULL;
    id INT   AUTO_INCREMENT;
    senha VARCHAR(30) NOT NULL;
    email VARCHAR(30) NOT NULL UNIQUE ;
    constraint id primary key (id)
);
CREATE TABLE Essay(
    tema VARCHAR(90) NOT NULL;
    id INT  AUTO_INCREMENT;
    texto VARCHAR(500) NOT NULL;
    essay_usser_id INT;
    FOREIGN KEY (essay_user_id) REFERENCES User(id);
    constraint id primary key (id)
);
CREATE DATABASE ESSAY1000;
USE ESSAY1000;
CREATE TABLE User (
    id INT AUTO_INCREMENT,
    nome VARCHAR(45)  NOT NULL,
    senha VARCHAR(255) NOT NULL,
    email VARCHAR(30)  NOT NULL UNIQUE,
    CONSTRAINT pk_user PRIMARY KEY (id)
);
CREATE TABLE Essay (
    id  INT AUTO_INCREMENT,
    tema VARCHAR(90)  NOT NULL,
    texto VARCHAR(500) NOT NULL,
    essay_user_id INT,
    CONSTRAINT pk_essay  PRIMARY KEY (id),
    CONSTRAINT fk_essay_user FOREIGN KEY (essay_user_id) REFERENCES User(id)
);
mysql -u root -p
mysql -u root -p
mysql -u root -p
mysql -u root -p
kbkbbkbkbkbbkb
mysql -u root -p
mysql -u root -p
mysql -p root -u
ls
ls mysql
mysql -u laravel -p
ls
cd atividade_01/
cd ..
cd.
cd atividade_01/
code ..
php artisan migrate:refresh 
php artisan make:model Category
php artisan make:model Publisher
php artisan make:model Book
php artisan make:seeder CategorySeeder
php artisan db:seed --class=CategorySeeder
php artisan make:factory AuthorFactory --model=Author
php artisan make:factory PublisherFactory --model=Publisher
php artisan make:factory CategoryFactory --model=Category
php artisan make:factory BookFactory --model=Book
php artisan make:seeder AuthorPublisherBookSeeder 
php artisan migrate:refresh --seed
php artisan migrate:refresh --seed
code ..
code ..
code ..
mysql -u laravel -p
